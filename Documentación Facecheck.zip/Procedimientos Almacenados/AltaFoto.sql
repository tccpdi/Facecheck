SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      Cedric Pernet
-- Create Date: 11/04/2019
-- Description: Procedimiento para dar de alta el ID de una foto y su nombre opcionalmente
-- =============================================
CREATE PROCEDURE AltaFoto
(
    @idFoto VARCHAR(100),
	@nombre VARCHAR(100) = NULL
)
AS
BEGIN
    SET NOCOUNT ON

    INSERT INTO DBO.FOTOS (id_foto, nombre) 
	VALUES(@idFoto, @nombre)
END
GO
