GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      Cedric Pernet
-- Create Date: 11/04/2019
-- Description: Procedimiento para dar de alta a una persona
-- =============================================
CREATE PROCEDURE AltaPersona
(
    @nombre VARCHAR(100),
	@paterno VARCHAR(50),
	@materno VARCHAR(50),
	@fechaIngreso DATE
)
AS
BEGIN
    SET NOCOUNT ON
	
	INSERT  INTO dbo.PERSONAS (Nombre, ApellidoPaterno, ApellidoMaterno, FechaIngreso, activo)  
	VALUES (@nombre, @paterno, @materno, @fechaIngreso, 1) 
END
GO
