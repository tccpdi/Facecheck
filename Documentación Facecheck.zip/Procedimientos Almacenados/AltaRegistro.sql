SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      Cedric Pernet
-- Create Date: 11/04/2019
-- Description: Procedimiento para dar de alta un registro con una persona, horario y horario-dia existentes
-- =============================================
CREATE PROCEDURE AltaRegistro
(
	@idDia VARCHAR(7),
	@TiempoRegistro DATETIME,
	@idPersona  INT
)
AS
BEGIN
    SET NOCOUNT ON
	INSERT INTO dbo.REGISTROS (fk_dia,TiempoRegistro,fk_persona, AnuladoRegistro, IrregularRegistro ) 
	VALUES (@idDia, @TiempoRegistro, @idPersona, 0, 0)
END
GO
