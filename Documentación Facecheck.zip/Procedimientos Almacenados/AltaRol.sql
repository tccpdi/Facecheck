SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      Cedric Pernet
-- Create Date: 11/04/2019
-- Description: Procedimiento para asignar un rol a una persona existente
-- =============================================
CREATE PROCEDURE AltaRol
(
	@idPersona INT,
	@idRol INT
)
AS
BEGIN    
    SET NOCOUNT ON
    UPDATE PERSONAS SET fk_rol = @idRol WHERE id_persona = @idPersona
END
GO
