SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      Cedric Pernet
-- Create Date: 03-05-2019
-- Description: Consultar personas
-- =============================================
CREATE PROCEDURE ConsultaPersonas

AS
BEGIN
    SET NOCOUNT ON
    SELECT * FROM PERSONAS
END
GO
