SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      Cedric Pernet
-- Create Date: 11/04/2019
-- Description: Procedimiento para agregar un nuevo horario, selecciona el �ltimo ID creado
-- =============================================
CREATE PROCEDURE AltaHorario
(
    @nombreHorario VARCHAR(100),
	@toleranciaDiaria TIME(7)
)
AS
BEGIN
    SET NOCOUNT ON
	INSERT INTO DBO.HORARIOS (nombre, ToleranciaDiaria)
	VALUES (@nombreHorario, @toleranciaDiaria)
	
END
GO
