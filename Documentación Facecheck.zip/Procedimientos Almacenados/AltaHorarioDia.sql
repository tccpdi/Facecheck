SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      Cedric Pernet
-- Create Date: 11/04/2019
-- Description: Procedimiento para dar de lata un horario de un d�a espec�fico, con un horario ya creado
-- ==============================================
CREATE PROCEDURE AltaHorarioDia
(    
    @idHorario INT,
	@idDia VARCHAR(7),
	@TiempoEntrada TIME(7),
	@TiempoSalida TIME(7)	
)
AS
BEGIN
    SET NOCOUNT ON
	INSERT INTO DBO.[HORARIOS-DIAS] (fk_horario, fk_dia, TiempoEntrada, TiempoSalida) 
	VALUES (@idHorario, @idDia, @TiempoEntrada, @TiempoSalida)
END
GO
