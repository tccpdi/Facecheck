SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      Cedric Pernet
-- Create Date: 20-06-2019
-- Description: Procedimiento para actualizar el horario de un d�a
-- =============================================
CREATE PROCEDURE ActualizarHorariosDias
(
	@idHorario INT,
	@dia VARCHAR(9),
    @tEntrada TIME,
	@tSalida TIME
)
AS
BEGIN
    SET NOCOUNT ON
    
	UPDATE dbo.HORARIOS_DIAS
	SET TiempoEntrada = @tEntrada, TiempoSalida = @tSalida
	WHERE @idHorario = fk_horario
	AND @dia = fk_dia
END
GO
